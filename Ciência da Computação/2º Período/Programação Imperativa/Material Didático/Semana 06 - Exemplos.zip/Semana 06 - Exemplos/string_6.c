#include <stdio.h>
#include <string.h>

int main()
{
    char* origem = "Pantanal";
    printf("%s\n", origem);

    char destino[20];
    strcpy(destino, origem); // string copy
    printf("%s\n", destino);

    return 0;
}

#include <stdio.h>

int main()
{
    char pais[10] = "Brasil";

    char estado[] = "Paraná";

    char* cidade = "Curitiba";

    printf("%s, %s, %s\n", pais, estado, cidade);

    pais[2] = 'e';
    estado[1] = 'i';
    //cidade[5] = 'a'; // causa erro de execução

    printf("%s, %s, %s\n", pais, estado, cidade);

    return 0;
}

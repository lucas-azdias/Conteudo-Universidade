#include <stdio.h>

int main()
{
    char* cantor = "John Lennon";
    cantor = "Nina Simone";

    const char* planeta = "Terra";
    planeta = "Venus";

    char* const estrela = "Sol";
    // estrela = "Maia"; // ERRO DE COMPILAÇÃO

    const char* const constelacao = "Gemini";
    // constelacao = "Taurus"; // ERRO DE COMPILAÇÃO

    return 0;
}

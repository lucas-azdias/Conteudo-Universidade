#include <stdio.h>

typedef char* Texto;

int main()
{
    Texto fruta;
    fruta = "abacaxi";
    puts(fruta);

    Texto animal = "zebra";
    puts(animal);

    return 0;
}

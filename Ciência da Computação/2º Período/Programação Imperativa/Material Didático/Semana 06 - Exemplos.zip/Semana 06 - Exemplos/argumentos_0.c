#include <stdio.h>

int main(int argc, char* argv[])
{
    printf("Número de argumentos: %d\n", argc);
    printf("Primeiro argumento: %s\n", argv[0]);

    return 0;
}

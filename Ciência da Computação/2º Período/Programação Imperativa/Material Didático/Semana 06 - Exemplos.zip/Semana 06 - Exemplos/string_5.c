#include <stdio.h>
#include <string.h>

int main()
{
    char origem[30] = "Pantanal";
    printf("%s\n", origem);

    char destino[6];
    strcpy(destino, origem); // ERRO DE EXECUÇÃO
    printf("%s\n", destino);

    return 0;
}

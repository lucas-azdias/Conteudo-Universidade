#include <stdio.h>
#include <string.h>

int main()
{
    char* nome = "Vinicius de Moraes";

    printf("%s\n", nome);

    printf("espaço ocupado pela variável: %lu\n", sizeof(nome));
    printf("comprimento da string: %lu\n", strlen(nome));

    printf("%c\n", nome[0]);
    printf("%c\n", nome[1]);
    printf("%c\n", nome[17]);
    printf("%c\n", nome[18]);
    printf("%c\n", nome[30]);

    return 0;
}

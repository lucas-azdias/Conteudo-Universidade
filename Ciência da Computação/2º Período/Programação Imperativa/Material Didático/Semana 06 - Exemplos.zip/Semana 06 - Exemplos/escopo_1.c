#include <stdio.h>

int x = 10; // declaração de variável global

void f()
{
    int x = 5; // declaração de variável local
    x = x * 2; // acesso a variável local
}

int main()
{
    x++; // acesso a variável global
    printf("%d\n", x);

    f();
    printf("%d\n", x);

    return 0;
}

#include <stdio.h>

#include "fonte_2_servico.h"

int main()
{
    double x = 4.0;
    double y = dobrar(x);
    printf("y = %f\n", y);
    return 0;
}

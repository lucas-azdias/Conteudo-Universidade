double dobrar(double x)
{
    return 2 * x;
}

#include "fonte_2_servico.h"

double dobrar(double x)
{
    return 2 * x;
}

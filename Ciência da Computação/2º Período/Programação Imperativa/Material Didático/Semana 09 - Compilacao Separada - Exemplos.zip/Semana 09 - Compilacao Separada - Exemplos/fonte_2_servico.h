#ifndef SERVICO_H
#define SERVICO_H

double dobrar(double);

#endif

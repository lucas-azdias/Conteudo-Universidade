double dobrar(double);

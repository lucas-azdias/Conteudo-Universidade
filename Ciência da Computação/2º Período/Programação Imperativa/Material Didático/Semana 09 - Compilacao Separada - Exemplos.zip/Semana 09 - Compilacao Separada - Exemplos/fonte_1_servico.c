#include "fonte_1_servico.h"

double dobrar(double x)
{
    return 2 * x;
}

#include <stdio.h>
#include <string.h>

int main()
{
    char palavra[10] = "Jiboia";
    int comprimento = strlen(palavra); // 6
    for (int i = 0; i < comprimento; i++)
        printf("%c\n", palavra[i]);
    puts("=======");

    char* p = palavra;
    printf("%c\n", *p); // J
    p++;
    printf("%c\n", *p); // i
    p++;
    printf("%c\n", *p); // b
    p++;
    printf("%c\n", *p); // o
    p++;
    printf("%c\n", *p); // i
    p++;
    printf("%c\n", *p); // a
    puts("=======");

    p = palavra;
    for (int i = 0; i < comprimento; i++)
        printf("%c\n", *(p+i));
    puts("=======");

    return 0;
}
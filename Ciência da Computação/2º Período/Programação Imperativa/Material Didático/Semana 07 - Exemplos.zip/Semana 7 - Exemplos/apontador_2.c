#include <stdio.h>

int main()
{
    int v[2][2] = {1, 2, 3, 4};
    printf("v[0][0]= %d\n", v[0][0]);
    printf("v[0][1]= %d\n", v[0][1]);
    printf("v[1][0]= %d\n", v[1][0]);
    printf("v[1][1]= %d\n", v[1][1]);

    int* p = &v[0][0];
    *p = 8;
    printf("v[0][0]= %d\n", v[0][0]);

    p++;
    *p = 7;
    printf("v[0][1]= %d\n", v[0][1]);

    p++;
    *p = 6;
    printf("v[1][0]= %d\n", v[1][0]);

    p++;
    *p = 5;
    printf("v[1][1]= %d\n", v[1][1]);

    return 0;
}

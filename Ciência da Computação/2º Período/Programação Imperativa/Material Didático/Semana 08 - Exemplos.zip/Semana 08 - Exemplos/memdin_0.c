#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define NUMERO_ELEMENTOS 10

int main()
{
    const size_t TAMANHO_ELEMENTO = sizeof(char);
    const size_t NUMERO_BYTES = NUMERO_ELEMENTOS * TAMANHO_ELEMENTO;

    char* buffer = (char*) malloc(NUMERO_BYTES);

    printf("tamanho: %zu ==> %p\n", NUMERO_BYTES, buffer);

    buffer[4] = 'w';
    printf("elemento na posição 4: %c\n", *(buffer+4));

    char* p = buffer + 4;
    *p = 'z';
    printf("elemento na posição 4: %c\n", buffer[4]);

    free(buffer);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

typedef struct {
    char nome[10];
    double raio;
    double distancia_do_sol;
} Planeta;

#define NUMERO_ELEMENTOS 10

int main()
{
    const size_t TAMANHO_ELEMENTO = sizeof(Planeta);
    const size_t NUMERO_BYTES = NUMERO_ELEMENTOS * TAMANHO_ELEMENTO;

    Planeta* buffer = (Planeta*) calloc(NUMERO_ELEMENTOS, TAMANHO_ELEMENTO);

    printf("tamanho: %zu ==> %p\n", NUMERO_BYTES, buffer);

    strcpy(buffer[4].nome, "Terra");
    buffer[4].raio = 6378.0;
    buffer[4].distancia_do_sol = 150000000.0;
    printf("elemento na posição 4: %s\n", (buffer+4)->nome);

    Planeta* p = buffer + 4;
    strcpy(p->nome, "Marte");
    printf("elemento na posição 4: %s\n", buffer[4].nome);

    free(buffer);

    return 0;
}

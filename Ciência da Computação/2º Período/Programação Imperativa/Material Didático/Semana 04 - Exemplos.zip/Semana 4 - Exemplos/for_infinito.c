#include <stdio.h>
int main( )
{
    for  (int i = 0, j = 10; ; )
    {
        printf("%d %d\n", i, j);
        i++;
        j--;
    }

  return 0;
}
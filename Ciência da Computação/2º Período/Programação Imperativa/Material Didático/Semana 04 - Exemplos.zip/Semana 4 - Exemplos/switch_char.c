#include <stdio.h>

int main()
{
    int vogais = 0, consoantes = 0, hifens = 0;

    char palavra[80];
    printf("Digite um palavra: ");
    scanf("%s", palavra);

    for (int i = 0; palavra[i] != '\0'; i++)
    switch ( palavra[i] )
    {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u': vogais++; break;
        case '-': hifens++; break;
        default:  consoantes++;
    }
    
    printf("vogais: %d, consoantes: %d, hifens: %d\n",
            vogais, consoantes, hifens);

    return 0;
}
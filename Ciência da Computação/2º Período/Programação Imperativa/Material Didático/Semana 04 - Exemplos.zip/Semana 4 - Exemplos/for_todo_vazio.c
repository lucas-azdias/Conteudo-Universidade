#include <stdio.h>
int main( )
{
    int i = 0, j = 10;

    for  ( ; ; )
    {
        printf("%d %d\n", i, j);
        i++;
        j--;
    }

  return 0;
}
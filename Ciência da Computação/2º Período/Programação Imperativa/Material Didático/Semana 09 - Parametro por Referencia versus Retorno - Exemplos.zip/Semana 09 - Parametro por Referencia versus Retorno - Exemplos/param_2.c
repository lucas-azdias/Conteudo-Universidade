#include <stdio.h>
#include <stdlib.h>

int* g()
{
    int* k = (int*)
        malloc(sizeof(int));
    *k = 10;
    return k;
}

int main()
{
    int* x;
    x = g();
    printf("%d\n", *x);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

void f(int** k)
{
    *k = (int*)
        malloc(sizeof(int));
    **k = 10;
}

int main()
{
    int** x;
    **x = 0;
    f(x);
    printf("%d\n", **x);

    return 0;
}

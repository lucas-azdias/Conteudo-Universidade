#include <stdio.h>

int g()
{
    return 10;
}

int main()
{
    int x = 0;
    x = g();
    printf("%d\n", x);

    return 0;
}

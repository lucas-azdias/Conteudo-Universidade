#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Pessoa
{
    char nome[50];
    int idade;
};

void f(struct Pessoa** k)
{
    *k = (struct Pessoa*) malloc (sizeof(struct Pessoa));
    strcpy((*k)->nome, "Maria");
    (*k)->idade = 20;
}

int main()
{
    struct Pessoa** x;
    f(x);
    printf("%s\n", (*x)->nome);
    printf("%d\n", (*x)->idade);

    return 0;
}

#include <stdio.h>

void showbitschar(char ch)
{
    for (int i = (sizeof(char) * 8) - 1; i >= 0; i--)
    {
       putchar(ch & (1u << i) ? '1' : '0');
    }
    printf("\n");
}

int main()
{
    for (char ch = 'A'; ch < 'z'; ch++)
    {
        printf("%c\t%d\t", ch, ch);
        showbitschar(ch);
    }

    return 0;
}

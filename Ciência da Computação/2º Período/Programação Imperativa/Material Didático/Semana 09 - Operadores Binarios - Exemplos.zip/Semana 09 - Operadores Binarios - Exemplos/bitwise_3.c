#include <stdio.h>

int main()
{
    int x = 7;

    int y = ~x + 1;

    printf("%d\n", y);

    return 0;
}

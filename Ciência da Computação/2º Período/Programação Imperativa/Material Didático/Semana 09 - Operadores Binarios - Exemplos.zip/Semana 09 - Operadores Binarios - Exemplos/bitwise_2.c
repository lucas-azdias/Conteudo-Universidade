#include <stdio.h>
#include <math.h>
#include <limits.h>
    
void showbitsint( int x )
{
    int i=0;
    for (i = (sizeof(int) * 8) - 1; i >= 0; i--)
    {
       putchar(x & (1u << i) ? '1' : '0');
    }
}

void show(int x)
{
    printf("%20d: ", x); showbitsint(x);
    putchar('\n');
}

int main()
{
    show(0);
    show(1);
    show(2);
    show(-1);
    show(-2);

    puts("MAIOR INTEIRO:");
    show(INT_MAX);
    show(pow(2, 31) - 1);

    puts("MENOR INTEIRO:");
    show(INT_MIN);
    show(-pow(2, 31));

    return 0;
}
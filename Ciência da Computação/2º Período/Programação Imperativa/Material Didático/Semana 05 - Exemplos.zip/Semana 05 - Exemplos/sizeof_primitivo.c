#include <stdio.h>
int main()
{
    int x = 10;
    printf("int: %lu\n", sizeof(x));

    unsigned int y = 10;
    printf("unsigned int: %lu\n", sizeof(y));

    short int z = 10;
    printf("short int: %lu\n", sizeof(z));

    long int w = 10;
    printf("long int: %lu\n", sizeof(w));

    float f = 10;
    printf("float: %lu\n", sizeof(f));

    double d = 10;
    printf("double: %lu\n", sizeof(d));

    char c = 'T';
    printf("char: %lu\n", sizeof(c));

    return 0;
}
#include <stdio.h>

int main()
{
    int numeros[] = {0, 1, 2, 3};
    
    printf("int[]: %lu\n", sizeof(numeros));

    printf("%d\n", numeros[3]);

    return 0;
}
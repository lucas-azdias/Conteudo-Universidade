#include <stdio.h>
#include <stdbool.h>

int main()
{
    bool calor = false;

    printf("bool: %lu\n", sizeof(calor));

    return 0;
}

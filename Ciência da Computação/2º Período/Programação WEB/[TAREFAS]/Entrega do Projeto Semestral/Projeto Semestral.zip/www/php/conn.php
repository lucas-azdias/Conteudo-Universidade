<?php

      $host = "127.0.0.1";
      $port = 3306;
      $user = "root";
      $password = "";
      $dbname = "mubak_db";

      $conn = mysqli_connect("$host:$port", $user, $password, $dbname)

?>

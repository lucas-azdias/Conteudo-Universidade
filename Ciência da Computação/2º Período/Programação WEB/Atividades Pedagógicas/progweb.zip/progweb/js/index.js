

fetch("php/listar.php", { 
    method: "GET" 
}).then(async function (resposta) {
    var objeto = await resposta.json();
    listarProdutos(objeto);
});


function listarProdutos(produtos){
   
}


<?php

    $con = mysqli_connect("host:porta", "usuariomysql", "senhamysql", "nomebancodedados");

?>
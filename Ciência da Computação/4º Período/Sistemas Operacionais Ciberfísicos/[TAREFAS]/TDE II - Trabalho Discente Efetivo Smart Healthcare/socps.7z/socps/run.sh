rm socps.native
rm -R build
make
./build/native/socps.native

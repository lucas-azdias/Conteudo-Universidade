package categoria;

public class CategoriaFolha extends Categoria {

	public CategoriaFolha(String nm) {
		super(nm);
	}

}

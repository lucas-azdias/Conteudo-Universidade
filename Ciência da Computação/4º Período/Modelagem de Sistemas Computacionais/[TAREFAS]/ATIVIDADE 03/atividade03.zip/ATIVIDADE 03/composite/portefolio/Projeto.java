package portefolio;

import modelo.Composicao;

public class Projeto extends Composicao {

	public Projeto(String nm) {
		super(nm);
	}

}

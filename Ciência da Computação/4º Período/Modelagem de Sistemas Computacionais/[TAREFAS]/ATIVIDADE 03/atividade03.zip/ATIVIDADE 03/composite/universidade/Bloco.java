package universidade;

import modelo.Composicao;

public class Bloco extends Composicao {

	public Bloco(String nm) {
		super(nm);
	}

}

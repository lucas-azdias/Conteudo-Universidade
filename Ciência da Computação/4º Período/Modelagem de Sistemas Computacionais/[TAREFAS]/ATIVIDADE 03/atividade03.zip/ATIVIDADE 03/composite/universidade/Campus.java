package universidade;

import modelo.Composicao;

public class Campus extends Composicao {

	public Campus(String nm) {
		super(nm);
	}

}

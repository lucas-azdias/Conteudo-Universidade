package portefolio;

import modelo.Composicao;

public class Atividade extends Composicao {

	public Atividade(String nm) {
		super(nm);
	}

}


package pgarquivo;

import modelo.Composicao;

public class Pasta extends Composicao {
    
    public Pasta(String nm){
        super(nm);
    }    
}

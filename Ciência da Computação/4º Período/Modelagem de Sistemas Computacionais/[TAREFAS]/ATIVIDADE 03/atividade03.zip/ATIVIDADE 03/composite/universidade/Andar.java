package universidade;

import modelo.Composicao;

public class Andar extends Composicao {

	public Andar(String nm) {
		super(nm);
	}

}

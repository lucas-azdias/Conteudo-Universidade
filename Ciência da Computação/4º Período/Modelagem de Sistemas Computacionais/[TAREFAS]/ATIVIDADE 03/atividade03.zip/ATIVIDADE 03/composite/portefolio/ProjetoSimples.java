package portefolio;

public class ProjetoSimples extends Projeto {

	public ProjetoSimples(String nm) {
		super(nm);
	}

}

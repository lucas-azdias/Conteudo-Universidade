package portefolio;

import modelo.Composicao;

public class Portefolio extends Composicao {

	public Portefolio(String nm) {
		super(nm);
	}

}

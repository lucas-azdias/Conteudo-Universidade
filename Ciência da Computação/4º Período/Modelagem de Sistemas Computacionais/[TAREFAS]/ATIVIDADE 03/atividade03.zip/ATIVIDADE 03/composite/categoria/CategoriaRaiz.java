package categoria;

public class CategoriaRaiz extends Categoria {

	public CategoriaRaiz(String nm) {
		super(nm);
	}

}

package universidade;

import modelo.Composicao;

public class Universidade extends Composicao {

	public Universidade(String nm) {
		super(nm);
	}

}

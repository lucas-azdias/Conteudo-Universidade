
public class Pago extends Estado {

	public Pago() {
		super();
	}
}

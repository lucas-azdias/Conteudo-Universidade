
public class Rejeitado extends Estado {

	public Rejeitado() {
		super();
	}
}


public class Cancelado extends Estado {

	public Cancelado() {
		super();
	}
}

abstract class Estado {
	
	public Estado() {
		
	}

	public Estado solicita() {
		return this;
	}
	public Estado cotacao() {
//		System.out.println("Classe Estado");
		return this;
	}
	public Estado encomenda() {
//		System.out.println("Classe Estado");
		return this;
	}
	public Estado entrega() {
//		System.out.println("Classe Estado");
		return this;
	}
	public Estado paga() {
//		System.out.println("Classe Estado");
		return this;
	}
	public Estado rejeita() {
//		System.out.println("Classe Estado");
		return this;
	}
	public Estado cancela() {
//		System.out.println("Classe Estado");
		return this;
	}
	public Estado arquiva() {
//		System.out.println("Classe Estado");
		return this;
	}
}
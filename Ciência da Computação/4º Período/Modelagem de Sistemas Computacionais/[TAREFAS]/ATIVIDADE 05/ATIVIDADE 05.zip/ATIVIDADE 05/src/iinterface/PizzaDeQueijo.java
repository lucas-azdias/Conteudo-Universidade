
package iinterface;


// Products: Sabores de Pizza
public interface PizzaDeQueijo extends Pizza{
    String preparar();
}

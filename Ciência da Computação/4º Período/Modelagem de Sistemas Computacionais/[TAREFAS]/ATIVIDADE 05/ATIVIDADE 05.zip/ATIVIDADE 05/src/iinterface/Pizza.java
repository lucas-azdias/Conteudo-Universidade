
package iinterface;


public interface Pizza {
        String preparar();
}



package iinterface;

// Strategy: Estratégias de Preparo para Pizzas
public interface EstrategiaDePreparo {
    String preparar();
}
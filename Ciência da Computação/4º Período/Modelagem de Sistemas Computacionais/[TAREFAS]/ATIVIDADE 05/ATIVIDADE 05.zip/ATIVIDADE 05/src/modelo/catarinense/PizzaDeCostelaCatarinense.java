
package modelo.catarinense;

import iinterface.PizzaDeCostela;


public class PizzaDeCostelaCatarinense implements PizzaDeCostela {

    @Override
    public String preparar() {
        return "Pizza Catarinense de Costela";
    }
}
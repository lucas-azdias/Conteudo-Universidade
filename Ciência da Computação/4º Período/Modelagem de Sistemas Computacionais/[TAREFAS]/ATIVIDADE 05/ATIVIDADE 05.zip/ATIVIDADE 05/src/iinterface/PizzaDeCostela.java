
package iinterface;


public interface PizzaDeCostela extends Pizza {
    String preparar();
}

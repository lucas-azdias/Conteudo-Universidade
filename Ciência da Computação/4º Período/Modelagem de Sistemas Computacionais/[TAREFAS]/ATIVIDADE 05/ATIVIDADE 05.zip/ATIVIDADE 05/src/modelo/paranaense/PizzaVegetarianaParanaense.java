
package modelo.paranaense;

import iinterface.PizzaVegetariana;


public class PizzaVegetarianaParanaense implements PizzaVegetariana {

    @Override
    public String preparar() {
        return "Pizza Paranaense Vegetariana";
    }
}

package modelo.paranaense;

import iinterface.PizzaDeCostela;


public class PizzaDeCostelaParanaense implements PizzaDeCostela {
 
    @Override
    public String preparar() {
        return "Pizza Paranaense de Costela";
    }
}

package modelo.paranaense;

import iinterface.PizzaDeMignon;


public class PizzaDeMignonParanaense implements PizzaDeMignon {

    @Override
    public String preparar() {
        return "Pizza Paranaense de Mignon";
    }
}
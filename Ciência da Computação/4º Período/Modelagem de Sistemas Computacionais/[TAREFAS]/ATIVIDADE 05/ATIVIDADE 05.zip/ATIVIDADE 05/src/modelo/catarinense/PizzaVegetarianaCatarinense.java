
package modelo.catarinense;

import iinterface.PizzaVegetariana;


public class PizzaVegetarianaCatarinense implements PizzaVegetariana {

    @Override
    public String preparar() {
        return "Pizza Catarinense Vegetariana";
    }
}

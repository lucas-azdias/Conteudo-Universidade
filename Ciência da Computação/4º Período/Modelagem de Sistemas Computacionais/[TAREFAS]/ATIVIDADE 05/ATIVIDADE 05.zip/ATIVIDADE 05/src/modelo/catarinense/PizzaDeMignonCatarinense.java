
package modelo.catarinense;

import iinterface.PizzaDeMignon;


public class PizzaDeMignonCatarinense implements PizzaDeMignon {

    @Override
    public String preparar() {
        return "Pizza Catarinense de Mignon";
    }
}

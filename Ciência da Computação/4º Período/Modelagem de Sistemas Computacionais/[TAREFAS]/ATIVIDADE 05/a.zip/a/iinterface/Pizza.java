
package a.iinterface;


public interface Pizza {
        String preparar();
}



package a.iinterface;


public interface PizzaVegetariana extends Pizza {
    String preparar();
}


package a.iinterface;


public interface PizzaDeCostela extends Pizza {
    String preparar();
}

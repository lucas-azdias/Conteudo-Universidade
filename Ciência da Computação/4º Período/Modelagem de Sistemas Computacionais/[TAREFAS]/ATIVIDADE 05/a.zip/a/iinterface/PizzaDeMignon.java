
package a.iinterface;


public interface PizzaDeMignon extends Pizza {
    String preparar();
}

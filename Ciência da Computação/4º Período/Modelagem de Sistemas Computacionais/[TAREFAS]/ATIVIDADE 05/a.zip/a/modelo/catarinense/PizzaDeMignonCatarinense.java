
package a.modelo.catarinense;

import a.iinterface.PizzaDeMignon;


public class PizzaDeMignonCatarinense implements PizzaDeMignon {

    @Override
    public String preparar() {
        return "Pizza Catarinense de Mignon";
    }
}

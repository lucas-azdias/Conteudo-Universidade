
package a.modelo.catarinense;

import a.iinterface.PizzaVegetariana;


public class PizzaVegetarianaCatarinense implements PizzaVegetariana {

    @Override
    public String preparar() {
        return "Pizza Catarinense Vegetariana";
    }
}

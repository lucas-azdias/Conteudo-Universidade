package a;

import a.fabrica.FabricaDePizza;
import a.fabrica.FabricaDePizzaCatarinense;
import a.fabrica.FabricaDePizzaGaucho;
import a.iinterface.EstrategiaDePreparo;
import a.iinterface.PizzaDeCostela;
import a.iinterface.PizzaDeMignon;
import a.iinterface.PizzaDeQueijo;
import a.iinterface.PizzaVegetariana;
import a.modelo.docorador.DecoradorDeCostelasExtra;
import a.modelo.docorador.DecoradorDeMignonExtra;
import a.modelo.docorador.DecoradorDeQueijoExtra;
import a.modelo.docorador.DecoradorDeVegetaisExtra;
import a.modelo.preparo.PreparoPremium;
import a.modelo.preparo.PreparoTradicional;



// Cliente: Exemplo de Uso
public class AplicacaoPedidoPizza {
    
    private static void print(String str){
        System.out.println(str);
    }
    
    public static void main(String[] args) {
        
        // Abstract Factory: Criando uma fábrica para pizza gaúcha
        FabricaDePizza fabricaDePizzaGaucho = new FabricaDePizzaGaucho();

        // Produtos concretos Products para pizza gaúcha
        PizzaDeQueijo pizzaDeQueijoGaucho = fabricaDePizzaGaucho.criarPizzaDeQueijo();
        PizzaVegetariana pizzaVegetarianaGaucho = fabricaDePizzaGaucho.criarPizzaVegetariana();
        PizzaDeCostela pizzaDeCostelaGaucho = fabricaDePizzaGaucho.criarPizzaDeCostela();
        PizzaDeMignon pizzaDeMignonGaucho = fabricaDePizzaGaucho.criarPizzaDeMignon();

        // Exibindo os sabores de pizza gaúcha
        System.out.println("\nPizza Gaúcha:");
        print(pizzaDeQueijoGaucho.preparar());
        print(pizzaVegetarianaGaucho.preparar());
        print(pizzaDeCostelaGaucho.preparar());
        print(pizzaDeMignonGaucho.preparar());

        // Strategy: Aplicando uma estratégia específica
        EstrategiaDePreparo preparoTradicional = new PreparoTradicional();
        EstrategiaDePreparo preparoPremium     = new PreparoPremium();

        // Decorator: Personalizando as pizzas
        System.out.println("\nPersonalizando Pizzas:");

        // Decorando pizza gaúcha de quatro queijos com preparo tradicional
        PizzaDeQueijo extraQueijoPizzaDeQueijoGaucho = new DecoradorDeQueijoExtra(pizzaDeQueijoGaucho, preparoTradicional);
        print(extraQueijoPizzaDeQueijoGaucho.preparar());

        // Decorando pizza gaúcha vegetariana com vegetais extras e preparo premium
        PizzaVegetariana extraVegetaisPizzaVegetarianaGaucho = new DecoradorDeVegetaisExtra(pizzaVegetarianaGaucho, preparoPremium);
        print(extraVegetaisPizzaVegetarianaGaucho.preparar());

        // Decorando pizza gaúcha de costela com costelas extras
        PizzaDeCostela extraCostelasPizzaDeCostelaGaucho = new DecoradorDeCostelasExtra(pizzaDeCostelaGaucho, preparoTradicional);
        print(extraCostelasPizzaDeCostelaGaucho.preparar());

        // Decorando pizza gaúcha de mignon com mignon extra e preparo premium
        PizzaDeMignon extraMignonPizzaDeMignonGaucho = new DecoradorDeMignonExtra(pizzaDeMignonGaucho, preparoPremium);
        print(extraMignonPizzaDeMignonGaucho.preparar());

        // Abstract Factory: Criando uma fábrica para pizza catarinense
        FabricaDePizza fabricaDePizzaCatarinense = new FabricaDePizzaCatarinense();

        // Concrete Products para pizza catarinense
        PizzaDeQueijo pizzaDeQueijoCatarinense = fabricaDePizzaCatarinense.criarPizzaDeQueijo();
        PizzaVegetariana pizzaVegetarianaCatarinense = fabricaDePizzaCatarinense.criarPizzaVegetariana();
        PizzaDeCostela pizzaDeCostelaCatarinense = fabricaDePizzaCatarinense.criarPizzaDeCostela();
        PizzaDeMignon pizzaDeMignonCatarinense = fabricaDePizzaCatarinense.criarPizzaDeMignon();

        // Exibindo os sabores de pizza catarinense
        System.out.println("\nPizza Catarinense:");
        print(pizzaDeQueijoCatarinense.preparar());
        print(pizzaVegetarianaCatarinense.preparar());
        print(pizzaDeCostelaCatarinense.preparar());
        print(pizzaDeMignonCatarinense.preparar());
        
        // acrescente aqui as chamadas para testar o que foi feito
        
        

    }
}

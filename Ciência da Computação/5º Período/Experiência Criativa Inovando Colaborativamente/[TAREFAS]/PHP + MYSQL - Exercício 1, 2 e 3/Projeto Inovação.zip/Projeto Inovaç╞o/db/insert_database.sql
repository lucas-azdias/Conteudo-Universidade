INSERT INTO users (id_users, nome, sobrenome, email, matricula, usuario, senha)
VALUES (NULL, "admin", "admin", "admin@admin.com", "00000000", "admin", "12345678");

import socket
import MyHashLib as HL


# O computador de BOB foi comprometido através de um ataque do tipo Watering Hole
# CHARLES induziu BOB a instalar um programa com malware que intercepta os pacotes enviados para rede e envia uma cópia para CHARLES
# Crie uma estratégia para que BOB consiga se logar em ALICE.
# A solução deve ser imune a ataques de REPETIÇÃO (REPLAY)

#TODO: crie uma variavel denominada SEQS do tipo lista

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ALICE = ('127.0.0.1', 9999)

while True:

    login = input('digite seu LOGIN: ')
    senha = input('digite sua SENHA: ')

# 1) BOB ENVIA UM HELLO PARA ALICE
    msg = HL.formataMensagem(['HELLO', login])
    s.sendto( msg, ALICE )
    s.sendto( msg, HL.CHARLES ) # essa linha simula a ação do MALWARE


# 2) BOB RECEBE UM CHALLENGE    
    data, addr = s.recvfrom(1024) 
    print('RECEBI: ', data)

    msg = HL.separaMensagem(data) 
    #TODO: A mensagem CHALLENGE tem 3 campos, pois inclui o SALT
    if len(msg) < 2 or msg[0] != "CHALLENGE": 
        print('recebi uma mensagem inválida')
        continue

# 3) BOB responde ao CHALLENGE com um novo CHALLENGE e o HASH da sua senha 
# -- troque string NONCE por um nonce em formato base64 convertido para string (decode) 
# -- troque o HASH_SENHA pelo HASH da senha com o challenge da ALICE (string)

    cs, cs64 = HL.geraNonce(128)
    cs_BOB = cs64.decode()
    
    cs_ALICE = msg[1]

    #TODO: calcular a senha_salgada (salt = msg[2])
    
    #TODO: substituir senha por senha_salgada
    hash_bytes, hash_string = HL.calculaHASH(senha + cs_ALICE )
    local_HASH = hash_string

    data = HL.formataMensagem(['CHALLENGE_RESPONSE', cs_BOB, local_HASH ])

    s.sendto(data, addr )
    s.sendto(data, HL.CHARLES ) # essa linha simula a ação do MALWARE

# 4) BOB recebe o resultado da autenticaçao
# -- e verifica se ALICE é o servidor verdadeiro
    data, addr = s.recvfrom(1024)
    print('RECEBI: ', data)
    msg = HL.separaMensagem(data) 
    resultado = msg[0]
    prova = msg[1]

    #local_hash = senha

    #TODO: substituir senha por senha_salgada
    hash_bytes, hash_string = HL.calculaHASH(senha + cs_BOB )
    local_HASH = hash_string

# 5) BOB se a senha está correta
    if resultado == 'SUCCESS' and local_HASH == prova:
        print('Este servidor é ALICE')
    else:
        print('Este servidor não é ALICE')
    
# 6) BOB recebe uma mensagem autenticada de ALICE

    while True:
        print('Aguardando mensagens do Servidor')
        data, addr = s.recvfrom(1024)
        print('RECEBI: ', data)

        msg = HL.separaMensagem(data) 
        
        #TODO verifique se a mensagem está duplicada

        if msg[0] == 'HMAC':
            #TODO: substituir senha por senha_salgada
            resultado = HL.verificaMensagem(data, senha) 
            if resultado: 
                #Adicione o SEQ na lista SEQS
                print(msg[1])
                continue
        
        print('recebi uma mensgem inválida')



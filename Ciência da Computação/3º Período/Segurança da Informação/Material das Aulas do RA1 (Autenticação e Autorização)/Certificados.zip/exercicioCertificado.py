import certLib as CERT

def criaCA():
    print('Essas ações são feitas pela Autoridade Certificado')
    

def geraCSR():
    print('Essas ações são feitas pela administrador do Servidor Web')
    
def assinaCSR():
    print('Essas ações são feitas pela CA')
    
def validaCertificado():
    print('Essas ações são feitas pelo navegador Web')
    

#--------------------------------------------------------------

# 1) Crie uma CA com a seguinte DN
# CN='PUCPR.br', O='Politecnica PUCPR', C='BR', S='Parana', L='Curitiba'
criaCA()

# 2) Crie um CSR para o servidor Web e assine com a CA
# CN='bcc.pucpr.br', O='Ciencia da Computacao', C='BR', S='Parana', L='Curitiba'
geraCSR()
assinaCSR()

# 3) Faça a verificação do Certificado pelo navegador Web
validaCertificado()


"""
PERGUNTAS:

1) Como o certificado da CA é validado?
2) Qual chave a CA usa para assinar o CSR do Servidor Web?
3) O certificado do servidor contém a chave privada do Servidor Web?
4) Quais informações o browser precisa conhecer para validar o certificado do Servidor Web?
"""



package com.poo.modulo5.provaRA1.Q3;

public class CCC {

    public static void main(String args[]) {
        
        GerenteDeProjeto carla = new GerenteDeProjeto("Carla");
        GerenteDeProjeto maria = new GerenteDeProjeto("Maria");
        GerenteDeProjeto joana = new GerenteDeProjeto("Joana");
        
        Desenvolvedor pedro = new Desenvolvedor("Pedro");
        Desenvolvedor andre = new Desenvolvedor("André");
        Desenvolvedor bruno = new Desenvolvedor("Bruno");
        
        carla.incluir_desenvolvedor(pedro);
        carla.incluir_desenvolvedor(andre);
        carla.incluir_desenvolvedor(bruno);
        
        maria.incluir_desenvolvedor(andre);
        maria.incluir_desenvolvedor(bruno);
        
        joana.incluir_desenvolvedor(bruno);
        
        carla.ganhar(10000.00);
        maria.ganhar(20000.00);
        joana.ganhar(10000.00);
        
        System.out.println(carla.resultado());
        System.out.println(maria.resultado());
        System.out.println(joana.resultado());
        System.out.println(pedro.resultado());
        System.out.println(andre.resultado());
        System.out.println(bruno.resultado());
    }
}

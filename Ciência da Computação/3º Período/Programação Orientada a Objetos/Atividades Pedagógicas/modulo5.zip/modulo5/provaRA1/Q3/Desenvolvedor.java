package com.poo.modulo5.provaRA1.Q3;

public class Desenvolvedor {

    private String nome;
    private double ganho;

    public Desenvolvedor(String nome) {
        this.nome = nome;
        ganho = 0;
    }

    public void ganhar(double valor) {
        ganho = ganho + valor;
    }

    public double resultado() {
        return ganho;
    }
}

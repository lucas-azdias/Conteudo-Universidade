
package com.poo.modulo5.provaRA1.Q3;

public class GerenteDeProjeto {
    private String nome;
    private double ganho;
    private Desenvolvedor junior, senior;
    
    public GerenteDeProjeto(String nome) {
        this.nome = nome;
        this.ganho = 0;
    }
    public void incluir_desenvolvedor(Desenvolvedor desenvolvedor) {
        if (this.junior == null)
            this.junior = desenvolvedor;
        else if (this.senior == null)
            this.senior = desenvolvedor;
    }
    public void ganhar(double valor) {
        if (this.junior != null) {
            this.junior.ganhar(0.1 * valor);
            valor = 0.9 * valor;
        }
        
        if (this.senior != null) {
            this.senior.ganhar(0.2 * valor);
            valor = 0.8 * valor;
        }
        this.ganho = this.ganho + valor;
    }
    public double resultado() {
        return this.ganho;
    }
}

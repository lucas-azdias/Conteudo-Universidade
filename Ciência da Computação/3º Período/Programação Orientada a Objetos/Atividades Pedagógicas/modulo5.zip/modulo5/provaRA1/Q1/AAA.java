package com.poo.modulo5.provaRA1.Q1;

public class AAA {

    private static void print(double x){
        System.out.println(x);
    }
    
    private static boolean ehPar(int i) {
        if (i % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }

    private static double f(double x, int k) {

        if (k < 0) {
            k = -k;
        }

        for (int i = 0; i < k; i++) {

            if (ehPar( i )) {
                x = x / 2;
            } else {
                x = -x / 2;
            }
        }
        return x;
    }

    public static void main(String args[]) {
        print( f(1024, 6) );
        print( f(-1024, -5) );
    }
}

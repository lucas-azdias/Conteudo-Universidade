 package com.poo.modulo5.provaRA1.Q4;

import java.util.ArrayList;

public class Carteira {

    private ArrayList<Ativo> carteiraDeAtivos;

    public Carteira() {
        carteiraDeAtivos = new ArrayList<Ativo>();
    }

    public void incluir(Ativo ativo) {
        carteiraDeAtivos.add(ativo);
    }

    public ArrayList<Ativo> selecionar_anteriores(int ano, String categoria) {
        /*
        Este método retorna o subconjunto de ativos da carteira de ativos/ações
        cujo ano de IPO da empresa seja anterior ao ano fornecido como parâmetro
        e cuja categoria seja igual à categoria fornecida como parâmetro.
         */
        
        ArrayList<Ativo> subconjuntoDeAtivos = new ArrayList<Ativo>();
        
        for (Ativo a: carteiraDeAtivos){
            
            if (a.pertence(categoria) && a.anterior(ano))
                subconjuntoDeAtivos.add(a);
        }
        
        return subconjuntoDeAtivos;
    }
          
}


package com.poo.modulo5.provaRA1.Q4;

public class Ativo {

    String empresa;
    String ticker;
    int ano_ipo;
    String categoria;
    
    Ativo(String empresa, String ticker, 
            int ano_ipo, String categoria)
    {
        this.empresa = empresa;
        this.ticker = ticker;
        this.ano_ipo = ano_ipo;
        this.categoria = categoria;
    }
    public void show()
    {
        System.out.println(empresa + " ["+ticker+"]");
    }
    public boolean anterior(int ano)
    {
        return (ano_ipo < ano);
    }
    public boolean pertence(String categoria)
    {
        return (this.categoria.equals(categoria));
    }    
}

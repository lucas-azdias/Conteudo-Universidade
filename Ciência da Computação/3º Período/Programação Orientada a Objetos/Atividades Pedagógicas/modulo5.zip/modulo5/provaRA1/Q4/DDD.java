package com.poo.modulo5.provaRA1.Q4;

import java.util.ArrayList;

public class DDD {

    public static void main(String args[]) {
        
        Carteira aposentadoria = new Carteira();
        
        aposentadoria.incluir(new Ativo("Bradesco", "BBDC4",1943, "BLUE CHIP"));
        aposentadoria.incluir(new Ativo("Unipar Carbocloro", "UNIP6", 1971, "SMALL CAP"));
        aposentadoria.incluir(new Ativo("Sanepar", "SAPR11", 2000, "SMALL CAP"));
        aposentadoria.incluir(new Ativo("Celulose Irani", "RANI3", 1999, "SMALL CAP"));
        aposentadoria.incluir(new Ativo("Itaú", "ITUB4", 2001, "BLUE CHIP"));
        aposentadoria.incluir(new Ativo("Klabin", "KLBN11", 1979, "BLUE CHIP"));
        
        ArrayList<Ativo> busca = 
            aposentadoria.selecionar_anteriores(1980, "BLUE CHIP");
        
        for (Ativo ativo : busca) {
            ativo.show();
        }
    }
}

package com.poo.modulo5.provaRA1.Q2;

public class BBB {

    private static char[] basesNitrogenadas = {'A', 'C', 'G', 'T'};
    private static String[] stringDeZerosUns = {"00", "01", "10", "11"};

    private static void print(String x) {
        System.out.println(x);
    }

    private static String codificar(char letra) {

        String resposta = "?";

        boolean encontrado = false;
        int i = 0;

        while (!encontrado && i < basesNitrogenadas.length) {
            if (letra == basesNitrogenadas[i]) {
                encontrado = true;
                resposta = stringDeZerosUns[i];
            } else {
                i++;
            }
        }
        return resposta;
    }

    private static String codificar(String palavra) {

        String codeBook = "";
        String noMatch = "[";

        for (int i = 0; i < palavra.length(); i++) {

            char c = palavra.charAt(i); // i-ésima letra da palavra
            String str = codificar(c);
            if (str.equals("?")) {
                noMatch = noMatch + c + ":" + i;
            } else {
                codeBook = codeBook + codificar(c);
            }
        }
        return codeBook + noMatch + "]";
    }

    public static void main(String args[]) {

        print(codificar("ATCGGCTATT"));
        print(codificar("AANTCGNCTA"));

    }
}
